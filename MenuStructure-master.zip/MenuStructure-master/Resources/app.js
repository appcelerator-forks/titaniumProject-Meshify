var Alloy = require("alloy"), _ = Alloy._, Backbone = Alloy.Backbone;

Alloy.Globals.itemLabel = 2 * Titanium.Platform.displayCaps.platformHeight / 100;

Alloy.Globals.itemLabel_2 = 2.5 * Titanium.Platform.displayCaps.platformHeight / 100;

Alloy.Globals.itemLabelSize_3 = 3 * Titanium.Platform.displayCaps.platformHeight / 100;

Alloy.Globals.itemLabelSize_4 = 4 * Titanium.Platform.displayCaps.platformHeight / 100;

Alloy.createController("index");