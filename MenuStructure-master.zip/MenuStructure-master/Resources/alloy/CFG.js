module.exports = {
    dependencies: {
        "com.drawermenu.widget": "1.0"
    },
    TitleColor: "#333333"
};