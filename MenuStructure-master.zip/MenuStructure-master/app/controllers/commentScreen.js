$.settingImg.addEventListener('click', function(e) {
	Ti.App.fireEvent('settingImg');
});